const { Collection } = require("discord.js");

const blacklistedWords = new Collection();

module.exports = { blacklistedWords };